/*
 * Copyright (c) 2024 iSoftStone Education Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "su_03t.h"

#include "los_task.h"
#include "ohos_init.h"

#include "iot_errno.h"
#include "iot_uart.h"

#include "smart_home.h"

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#define UART2_HANDLE EUART2_M1

#define MSG_QUEUE_LENGTH                                16
#define BUFFER_LEN                                      50

extern bool door_left_state;
extern bool door_right_state;
extern bool motor_state;
extern bool light_state;
extern bool auto_state,gesture_state,iot_state;
extern bool add_hum_state;
extern bool ultra1_state ;
extern bool ultra2_state ;
extern bool ultra3_state ;
extern bool pwm_light_state;
extern bool ultra4_state ;
extern unsigned int m_su03_msg_queue;
extern unsigned int ultra_data1,ultra_data2,ultra_data3,ultra_data4,ultra_switch,ultra_flag,last_ultra_flag;
extern int page_flag;
extern float ppm,o2_value;
extern int co2_value;
/***************************************************************
* 函数名称: su_03t_thread
* 说    明: 语音模块处理线程
* 参    数: 无
* 返 回 值: 无
***************************************************************/
static void su_03t_thread(void *arg)
{
    IotUartAttribute attr;
    double *data_ptr = NULL;
    unsigned int ret = 0;

    IoTUartDeinit(UART2_HANDLE);
    
    attr.baudRate = 115200;
    attr.dataBits = IOT_UART_DATA_BIT_8;
    attr.pad = IOT_FLOW_CTRL_NONE;
    attr.parity = IOT_UART_PARITY_NONE;
    attr.rxBlock = IOT_UART_BLOCK_STATE_BLOCK;
    attr.stopBits = IOT_UART_STOP_BIT_1;
    attr.txBlock = IOT_UART_BLOCK_STATE_NONE_BLOCK;
    
    ret = IoTUartInit(UART2_HANDLE, &attr);
    if (ret != IOT_SUCCESS)
    {
        printf("%s, %d: IoTUartInit(%d) failed!\n", __FILE__, __LINE__, ret);
        return;
    }

    while(1)
    {
        uint8_t data[64] = {0};
        uint8_t rec_len = IoTUartRead(UART2_HANDLE, data, sizeof(data));

        LOS_QueueRead(m_su03_msg_queue, (void *)&data_ptr, BUFFER_LEN, LOS_WAIT_FOREVER);

        printf("uart2 read %d  bytes:\n",rec_len);
        for(int i = 0;i< rec_len;i++){
            printf("%02x \r\n",data[i]);
        }
        printf("\r\n");

        if(last_ultra_flag!=ultra_flag&&auto_state)
        {
          switch(ultra_flag)
          {
            case 1:su03t_send_uchar_msg(5,ultra_data1);break;
            case 2:su03t_send_uchar_msg(6,ultra_data2);break;
            case 3:su03t_send_uchar_msg(7,ultra_data3);break;
            case 4:su03t_send_uchar_msg(8,ultra_data4);break;
          }
          last_ultra_flag=ultra_flag;
        }

        if (rec_len != 0)
        {
            uint16_t command = data[0] << 8 | data[1];
            if (command == auto_state_on)
            {
                auto_state = true;
            }
            else if (command == auto_state_off)
            {
                auto_state = false;
            }
            if (command == gesture_on)
            {
                gesture_state = true;
            }
            else if (command == gesture_off)
            {
                gesture_state = false;
            }
            if (command == door_left_on)
            {
                door_left_state = true;
            }
            else if (command == door_left_off)
            {
                door_left_state = false;
            }
            if (command == door_right_on)
            {
                door_right_state = true;
            }
            else if (command == door_right_off)
            {
                door_right_state = false;
            }                                    
            else if(command == light_state_on)
            {
                light_state = true;
            }
            else if(command == light_state_off)
            {
                light_state = false;
            }
            else if(command == pwm_light_on)
            {
                pwm_light_state = true;
            }
            else if(command == pwm_light_off)
            {
                pwm_light_state = false;
            }            
            else if(command == motor_state_on)
            {
                motor_state = true;
            }
            else if(command == motor_state_off)
            {
                motor_state = false;
            }
            else if(command == illumination_get)
            {
                su03t_send_double_msg(3, data_ptr[0]);
            }            
            else if(command == temperature_get)
            {
                su03t_send_double_msg(1, data_ptr[1]);
            }
            else if(command == humidity_get)
            {
                su03t_send_double_msg(2, data_ptr[2]);
            }
            else if(command == carbon_get)
            {
                su03t_send_double_msg(10, (double)co2_value);
            }
            else if(command == oxygen_get)
            {
                su03t_send_double_msg(11, (double)o2_value);
            }            
            else if(command == add_hum_state_on)
            {
                add_hum_state = true;
            }
            else if(command == add_hum_state_off)
            {
                add_hum_state = false;
            }
            else if(command == ultra1_on)
            {
                ultra1_state = true;
            }            
            else if(command == ultra1_off)
            {
                ultra1_state = false;
            }
            else if(command == ultra2_on)
            {
                ultra2_state = true;
            }            
            else if(command == ultra2_off)
            {
                ultra2_state = false;
            }
            else if(command == ultra3_on)
            {
                ultra3_state = true;
            }            
            else if(command == ultra3_off)
            {
                ultra3_state = false;
            }
            else if(command == ultra4_on)
            {
                ultra4_state = true;
            }            
            else if(command == ultra4_off)
            {
                ultra4_state = false;
            }
            else if(command == page_1)
            {
                page_flag = 1;
            }
            else if(command == page_2)
            {
                page_flag = 2;
            }
            else if(command == page_3)
            {
                page_flag = 3;
            }
        }
   
        // if(ultra_data2<ultra_switch)
        //     su03t_send_uchar_msg(6,ultra_data2);
        // if(ultra_data3<ultra_switch)
        //     su03t_send_uchar_msg(7,ultra_data3);
        // if(ultra_data4<ultra_switch)
        //     su03t_send_uchar_msg(5,0x20);
        //LOS_Msleep(500);
    }
}

void su03t_send_uchar_msg(uint8_t index, uint8_t dat)
{
    uint8_t buf[50] = {0};
    uint8_t *buf_ptr = buf;

    *buf_ptr = 0xAA;
    buf_ptr++;
    *buf_ptr = 0x55;
    buf_ptr++;
    *buf_ptr = index;
    buf_ptr++;

        *buf_ptr = dat;
        buf_ptr++;
    // for (uint8_t i = 0; i < sizeof(double); i++)
    // {
    //     *buf_ptr = u8_ptr[i];
    //     buf_ptr++;
    // }

    *buf_ptr = 0x55;
    buf_ptr++;
    *buf_ptr = 0xAA;

    IoTUartWrite(UART2_HANDLE, buf, sizeof(buf));
}

/***************************************************************
* 函数名称: su03t_send_double_msg
* 说    明: 发送double类型数据到语音模块
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void su03t_send_double_msg(uint8_t index, double dat)
{
    uint8_t buf[50] = {0};
    uint8_t *buf_ptr = buf;
    uint8_t *u8_ptr = (uint8_t *)&dat;

    *buf_ptr = 0xAA;
    buf_ptr++;
    *buf_ptr = 0x55;
    buf_ptr++;
    *buf_ptr = index;
    buf_ptr++;

    for (uint8_t i = 0; i < sizeof(double); i++)
    {
        *buf_ptr = u8_ptr[i];
        buf_ptr++;
    }

    *buf_ptr = 0x55;
    buf_ptr++;
    *buf_ptr = 0xAA;

    IoTUartWrite(UART2_HANDLE, buf, sizeof(buf));
}

/***************************************************************
* 函数名称: su03t_init
* 说    明: 语音模块初始化
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void su03t_init(void)
{
    unsigned int thread_id;
    TSK_INIT_PARAM_S task = {0};
    unsigned int ret = LOS_OK;

    task.pfnTaskEntry = (TSK_ENTRY_FUNC)su_03t_thread;
    task.uwStackSize = 2048;
    task.pcName = "su-03t thread";
    task.usTaskPrio = 24;
    ret = LOS_TaskCreate(&thread_id, &task);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;
    }
}
