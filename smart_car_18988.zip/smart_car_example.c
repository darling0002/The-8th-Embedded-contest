/*
 * Copyright (c) 2024 iSoftStone Education Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdbool.h>

#include "los_task.h"
#include "ohos_init.h"
#include "iot_uart.h"
#include "iot_errno.h"
#include "smart_home.h"
#include "iot_pwm.h"
#include "picture.h"
#include "lcd.h"
#include "los_swtmr.h"
#include "mq2.h"
#include "iot_adc.h"
#include "iot_gpio.h"

#include "iot.h"
#include "cmsis_os.h"
#include "config_network.h"

#define MSG_QUEUE_LENGTH 16
#define BUFFER_LEN 50

bool motor_state = false;
bool light_state = false;
bool auto_state = false;
bool last_auto_state = false;
bool add_hum_state = false;
bool ultra1_state = false;
bool ultra2_state = false;
bool ultra3_state = false;
bool ultra4_state = false;
bool pwm_light_state= false;
bool door_left_state = false;
bool door_right_state = false;
static unsigned int m_msg_queue;
unsigned int m_su03_msg_queue;

#define UART_ID                 EUART0_M0
#define PWM_PB5 EPWMDEV_PWM1_M1
#define PWM_PB4 EPWMDEV_PWM0_M1
#define PWM_PD0 EPWMDEV_PWM7_M1
#define BEEP_PORT EPWMDEV_PWM5_M0

#define STRING_MAXSIZE          128
#define CAL_PPM 20 // 校准环境中PPM值
#define RL 1       // RL阻值
static float m_r0; // 元件在干净空气中的阻值
#define MQ2_ADC_CHANNEL 4
#define KEY_ADC_CHANNEL 7

int duty1,duty2;
unsigned int ultra_data1=50,ultra_data2=50,ultra_data3=50,ultra_data4=50,ultra_switch=15,ultra_flag=0,last_ultra_flag=0;
int page_flag=1,page_flag_last=1,light_switch=50,hum_switch=80,temp_switch=40;
bool exit1_state,exit2_state,exit3_state,exit4_state;
bool iot_state,gesture_state;
float ppm,o2_value;
int co2_value;
uint8_t tx_data[5]={0xff,0,0,50,0xfe};

static unsigned int adc_dev_init()
{
    unsigned int ret = 0;

    /* 初始化ADC */
    ret = IoTAdcInit(KEY_ADC_CHANNEL);
    return 0;
}
static float adc_get_voltage()
{
    unsigned int ret = IOT_SUCCESS;
    unsigned int data = 0;
    /* 获取ADC值 */
    ret = IoTAdcGetVal(KEY_ADC_CHANNEL, &data);
    return (float)(data * 3.3 / 1024.0);
}

void timer1_timeout(void *arg)
{
    static uint8_t i=1;
    //printf("%d\n",duty1);
    if(i)
    {
        duty1++;
        if(duty1==100)
            i=!i; 
    }
    if(!i)
    {
        duty1--;
        if(duty1==0)
            i=!i; 
    }    
}
/***************************************************************
 * 函数名称: smart_hone_thread
 * 说    明: 智慧家居主线程
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void smart_hone_thread(void *arg)
{
    double *data_ptr = NULL;
    double illumination_range = 50.0;
    double temperature_range = 35.0;
    double humidity_range = 80.0;
    unsigned int timer_id1, timer_id2;

    lcd_dev_init();
    motor_dev_init();
    //light_dev_init();
    su03t_init();
    IoTPwmInit(PWM_PB5);
    IoTPwmInit(PWM_PD0);
    IoTPwmInit(PWM_PB4);
    IoTPwmStart(PWM_PB5, 0, 50);
    IoTPwmStart(PWM_PD0, 0, 50);
    IoTPwmStart(PWM_PB4, 0, 50);
    //IoTPwmInit(BEEP_PORT);
    mq2_dev_init();
    lcd_load_ui();
    mq2_ppm_calibration();
    LOS_SwtmrCreate(10, LOS_SWTMR_MODE_PERIOD, timer1_timeout, &timer_id1, NULL);
    LOS_SwtmrStart(timer_id1);
    while (1)
    {
        //IoTPwmStart(BEEP_PORT, 50, 1000);
        //IoTPwmStart(PWM_PB4, 0, 50);
        LOS_QueueRead(m_msg_queue, (void *)&data_ptr, BUFFER_LEN, LOS_WAIT_FOREVER);

        if (data_ptr[0] < light_switch && auto_state)
        {
            light_state = true;
            IoTPwmStart(PWM_PB4, 99, 50);
            //light_set_state(light_state);
        }
        else if (data_ptr[0] > light_switch && auto_state)
        {
            light_state = false;
            IoTPwmStart(PWM_PB4, 1, 50);
            //light_set_state(light_state);
        }
        // else if (!auto_state)
        // {
        //     if(pwm_light_state)
        //        IoTPwmStart(PWM_PB4, duty1, 50);
        //     else if(light_state)
        //         IoTPwmStart(PWM_PB4, 99, 50);
        //     else
        //         IoTPwmStop(PWM_PB4);
        // }

        if (((int)data_ptr[1] > temp_switch) && auto_state)
        {
            motor_state = true;
            motor_set_state(motor_state);
        }        
        else if (((int)data_ptr[1] < temp_switch ) && auto_state)
        {
            motor_state = false;
            motor_set_state(motor_state);
        }
        if (((int)data_ptr[2] > hum_switch) && auto_state)
        {
            //motor_state = true;
            add_hum_state = false;
            //motor_set_state(motor_state);
        }
        else if (((int)data_ptr[2] < hum_switch) && auto_state)
        {
            add_hum_state = true;
        }
        else if (!auto_state)
        {
            motor_set_state(motor_state);
        }
        if(page_flag_last!=page_flag)
        {
            page_flag_last=page_flag;
            lcd_fill(0, 0, LCD_W, LCD_H, LCD_WHITE);
            lcd_load_ui();
        }
        
        if(page_flag==1)
        {
        lcd_set_illumination(data_ptr[0]);
        lcd_set_temperature(data_ptr[1]);
        lcd_set_humidity(data_ptr[2]);
        lcd_set_light_state(light_state);
        lcd_set_motor_state(motor_state);
        lcd_set_auto_state(auto_state);
        lcd_add_hum_state(add_hum_state);
        lcd_show_float_num1(200,90,ppm,4,LCD_GREEN, LCD_WHITE, 24); 
        lcd_show_int_num(200,170,co2_value,4,LCD_GREEN, LCD_WHITE, 24);         
        lcd_show_float_num1(200,130,o2_value,4,LCD_GREEN, LCD_WHITE, 24); 

        //lcd_show_picture(280,0, 32,32, img_wifi_on);
        }
        else if(page_flag==2)
        {
            lcd_show_int_num(80, 80, ultra_data1, 3, LCD_GREEN, LCD_WHITE, 24);
            lcd_show_int_num(80, 105, ultra_data2, 3, LCD_GREEN, LCD_WHITE, 24);
            lcd_show_int_num(80, 130, ultra_data3, 3, LCD_GREEN, LCD_WHITE, 24);
            lcd_show_int_num(80, 155, ultra_data4, 3, LCD_GREEN, LCD_WHITE, 24);
            lcd_show_int_num(80, 180, ultra_switch, 3, LCD_GREEN, LCD_WHITE, 24);
            if(ultra1_state||ultra_flag==1||exit1_state)
                lcd_show_string(200, 80, "on ", LCD_GREEN, LCD_WHITE, 24, 0);
            else
                lcd_show_string(200, 80, "off", LCD_RED, LCD_WHITE, 24, 0);   
            if(ultra2_state||ultra_flag==2||exit2_state)
                lcd_show_string(200, 105, "on ", LCD_GREEN, LCD_WHITE, 24, 0);
            else
                lcd_show_string(200, 105, "off", LCD_RED, LCD_WHITE, 24, 0);
            if(ultra3_state||ultra_flag==3||exit3_state)
                lcd_show_string(200, 130, "on ", LCD_GREEN, LCD_WHITE, 24, 0);
            else
                lcd_show_string(200, 130, "off", LCD_RED, LCD_WHITE, 24, 0);
            if(ultra4_state||ultra_flag==4||exit4_state)
                lcd_show_string(200, 155, "on ", LCD_GREEN, LCD_WHITE, 24, 0);
            else
                lcd_show_string(200, 155, "off", LCD_RED, LCD_WHITE, 24, 0);                
            //lcd_show_picture(280,0, 32,32, img_wifi_off);  
        }
        else if(page_flag==3)
        {
            lcd_show_int_num(140, 80, ultra_switch, 3, LCD_GREEN, LCD_WHITE, 24);  
            lcd_show_int_num(140, 105, temp_switch, 3, LCD_GREEN, LCD_WHITE, 24);    
            lcd_show_int_num(140, 130, hum_switch, 3, LCD_GREEN, LCD_WHITE, 24);
            lcd_show_int_num(140, 155, light_switch, 4, LCD_GREEN, LCD_WHITE, 24);    
        } 
        if(iot_state)
            lcd_show_picture(280,0, 32,32, img_wifi_on);
        else
            lcd_show_picture(280,0, 32,32, img_wifi_off);
        
    }
}

void gpio_isr1_func(void *args)
{
    if(gesture_state)
    {
    exit1_state=true;exit2_state=false,exit3_state=false,exit4_state=false;
    }
}
void gpio_isr2_func(void *args)
{
       if(gesture_state)
    {
        exit1_state=false;exit2_state=true,exit3_state=false,exit4_state=false;      
    }
}
void gpio_isr3_func(void *args)
{
        if(gesture_state)
    {
        exit1_state=false;exit2_state=false,exit3_state=true,exit4_state=false;
    }
}
void gpio_isr4_func(void *args)
{
       if(gesture_state)
    {
        exit1_state=false;exit2_state=false,exit3_state=false,exit4_state=true;       
    }
}


void diy_thread(void *args) 
{
    float voltage;

    
    IoTGpioInit(GPIO0_PB0);
    IoTGpioInit(GPIO0_PB1);
    IoTGpioInit(GPIO0_PA2);
    IoTGpioInit(GPIO0_PA3);
    IoTGpioSetDir(GPIO0_PB0, IOT_GPIO_DIR_IN);
    IoTGpioSetDir(GPIO0_PB1, IOT_GPIO_DIR_IN);
    IoTGpioSetDir(GPIO0_PA2, IOT_GPIO_DIR_IN);
    IoTGpioSetDir(GPIO0_PA3, IOT_GPIO_DIR_IN);
    IoTGpioRegisterIsrFunc(GPIO0_PB0, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_RISE_LEVEL_HIGH, gpio_isr1_func, NULL);
    IoTGpioRegisterIsrFunc(GPIO0_PB1, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_RISE_LEVEL_HIGH, gpio_isr2_func, NULL);
    IoTGpioRegisterIsrFunc(GPIO0_PA2, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_RISE_LEVEL_HIGH, gpio_isr3_func, NULL);
    IoTGpioRegisterIsrFunc(GPIO0_PA3, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_RISE_LEVEL_HIGH, gpio_isr4_func, NULL);
    IoTGpioSetIsrMask(GPIO0_PB0, FALSE);
    IoTGpioSetIsrMask(GPIO0_PB1, FALSE);
    IoTGpioSetIsrMask(GPIO0_PA2, FALSE);
    IoTGpioSetIsrMask(GPIO0_PA3, FALSE);
    IoTGpioInit(GPIO0_PA5);
    IoTGpioSetDir(GPIO0_PA5, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(GPIO0_PA5, IOT_GPIO_VALUE0);
    IoTPwmInit(PWM_PB5);
    IoTPwmInit(PWM_PD0);
    IoTPwmInit(PWM_PB4);
    IoTPwmStart(PWM_PB5, 0, 50);
    IoTPwmStart(PWM_PD0, 0, 50);
    IoTPwmStart(PWM_PB4, 0, 50);
    adc_dev_init();
    // IoTGpioGetInputVal(GPIO0_PA2,a2);
    while (1)
    {
        if (!auto_state)
        {
            if(pwm_light_state)
               IoTPwmStart(PWM_PB4, duty1, 50);
            else if(light_state)
                IoTPwmStart(PWM_PB4, 99, 50);
            else
                IoTPwmStop(PWM_PB4);
        }
        if(door_left_state)
            IoTPwmStart(PWM_PD0, 5, 50); 
        else
            IoTPwmStart(PWM_PD0, 10, 50);
        if(door_right_state)
            IoTPwmStart(PWM_PB5, 10, 50); 
        else
            IoTPwmStart(PWM_PB5, 5, 50);             
        if(add_hum_state)
            IoTGpioSetOutputVal(GPIO0_PA5,IOT_GPIO_VALUE0);
        else
            IoTGpioSetOutputVal(GPIO0_PA5,IOT_GPIO_VALUE1);
        // IoTPwmStart(PWM_PB5, duty1, 50);
        // IoTPwmStart(PWM_PD0, duty2, 50);
        // IoTPwmStart(PWM_PB4, duty1, 50);
        voltage = adc_get_voltage();
        if(voltage >3.2){
            // printf("no key\n");
        }else if (voltage > 1.50){ //printf("LEFT\n");
            //LOS_Msleep(20);
            if(voltage > 1.50)
            {
                // IoTPwmStart(PWM_PD0, 5, 50); 
                // IoTPwmStart(PWM_PB5, 5, 50); 
                page_flag=1;
            }
        }else if (voltage > 1.0){ //printf("DOWN\n");
            //LOS_Msleep(20);
            if(voltage > 1.0)
            {
                // IoTPwmStart(PWM_PD0, 10, 50); 
                // IoTPwmStart(PWM_PB5, 10, 50); 
                page_flag=2;
            }           
        }else if (voltage > 0.5){//printf("RIGHT\n");
            //LOS_Msleep(20);
            if(voltage > 0.5)
            {
                page_flag=3;
            }             
        }else{//printf("UP\n");
            //LOS_Msleep(20);
            
        }
    }
    
}
/***************************************************************
 * 函数名称: device_read_thraed
 * 说    明: 设备读取线程
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void device_read_thraed(void *arg)
{
    double read_data[3] = {0};

    unsigned int ret;
    IotUartAttribute attr;
    unsigned char str[] = "HelloWorld!";
    unsigned char recv_buffer[STRING_MAXSIZE];
    unsigned int recv_length = 0;
    unsigned int i;
    char bit[4];
    e_iot_data iot_data = {0};

    IoTUartDeinit(UART_ID);

    attr.baudRate = 9600;
    attr.dataBits = IOT_UART_DATA_BIT_8;
    attr.pad = IOT_FLOW_CTRL_NONE;
    attr.parity = IOT_UART_PARITY_NONE;
    attr.rxBlock = IOT_UART_BLOCK_STATE_NONE_BLOCK;
    attr.stopBits = IOT_UART_STOP_BIT_1;
    attr.txBlock = IOT_UART_BLOCK_STATE_NONE_BLOCK;
    
    /* 初始化串口 */
    ret = IoTUartInit(UART_ID, &attr);
    IoTUartWrite(UART_ID, str, strlen(str));
    i2c_dev_init();

    //lcd_dev_init();
    while (1)
    {
        if(last_auto_state!=auto_state)
        {
            if(auto_state)
            {
            tx_data[2]=0x0a;
            tx_data[3]=ultra_switch;
            IoTUartWrite(UART_ID, tx_data, sizeof(tx_data));
            }
            else
            {
            tx_data[2]=0x0b;
            tx_data[3]=ultra_switch;
            IoTUartWrite(UART_ID, tx_data, sizeof(tx_data));                
            }
            last_auto_state=auto_state;
        }
        if(ultra1_state||exit1_state)
        {
            tx_data[1]=0x01;
            tx_data[3]=ultra_switch;
            IoTUartWrite(UART_ID, tx_data, sizeof(tx_data));
        }
        else if(ultra2_state||exit2_state)
        {
            tx_data[1]=0x02;
            tx_data[3]=ultra_switch;
            IoTUartWrite(UART_ID, tx_data, sizeof(tx_data));
        }
        else if(ultra3_state||exit3_state)
        {
            tx_data[1]=0x03;
            tx_data[3]=ultra_switch;
            IoTUartWrite(UART_ID, tx_data, sizeof(tx_data));
        }
        else if(ultra4_state||exit4_state)
        {
            tx_data[1]=0x04;
            tx_data[3]=ultra_switch;
            IoTUartWrite(UART_ID, tx_data, sizeof(tx_data));
        }
        else if(!auto_state)
        {
            tx_data[1]=0x05;
            IoTUartWrite(UART_ID, tx_data, sizeof(tx_data));            
        }
        
        bh1750_read_data(&read_data[0]);
        sht30_read_data(&read_data[1]);
        LOS_QueueWrite(m_msg_queue, (void *)&read_data, sizeof(read_data), LOS_WAIT_FOREVER);
        LOS_QueueWrite(m_su03_msg_queue, (void *)&read_data, sizeof(read_data), LOS_WAIT_FOREVER);

        ppm = get_mq2_ppm();
        recv_length = 0;
        memset(recv_buffer, 0, sizeof(recv_buffer));
        recv_length = IoTUartRead(UART_ID, recv_buffer, sizeof(recv_buffer));
        //IoTUartWrite(UART_ID, recv_buffer, strlen(recv_buffer));
        if (recv_length >= 10)
        {
            if(recv_buffer[0]==0xff&&recv_buffer[9]==0xfe)
            {
            ultra_data1=recv_buffer[1];
            ultra_data2=recv_buffer[2];
            ultra_data3=recv_buffer[3];
            ultra_data4=recv_buffer[4];
            //(float)o2_value/10
            o2_value=(float)((recv_buffer[5] << 8) | recv_buffer[6])/10;
            co2_value = (recv_buffer[7] << 8) | recv_buffer[8];
            recv_buffer[0]=0;
            recv_buffer[9]=0;
            }
        }
        if (mqtt_is_connected()) 
        {
            // 发送iot数据
            iot_data.illumination = read_data[0];
            iot_data.temperature = read_data[1];
            iot_data.humidity = read_data[2];
            iot_data.light_state = light_state;
            iot_data.motor_state = motor_state;
            iot_data.auto_state = auto_state;
            iot_data.add_hum_state = add_hum_state;
            
            iot_data.oxygen=o2_value;
            iot_data.carbon=co2_value;
            iot_data.ppm=ppm;
            iot_data.ultra_switch=ultra_switch;
            iot_data.hum_switch=hum_switch;
            iot_data.light_switch=light_switch;
            iot_data.temp_switch=temp_switch;
            // iot_data.auto_state = auto_state;
            send_msg_to_mqtt(&iot_data);

            iot_state=true;
        }else{
            
            iot_state=false;
        }

        if(ultra_data1<ultra_switch)
        {
            ultra_flag=1;
            //last_ultra_flag=ultra_flag;
        }   
        if(ultra_data2<ultra_switch)
        {
            ultra_flag=2;
            //last_ultra_flag=ultra_flag;
        }            
        if(ultra_data3<ultra_switch)
        {
            ultra_flag=3;
            //last_ultra_flag=ultra_flag;
        }            
        if(ultra_data4<ultra_switch)
        {
            ultra_flag=4;
            //last_ultra_flag=ultra_flag;
        }
        //LOS_Msleep(100);
    }
}

#define ROUTE_SSID      "input"          // WiFi账号
#define ROUTE_PASSWORD "11111111"       // WiFi密码

#define MSG_QUEUE_LENGTH                                16
#define BUFFER_LEN                                      50
/***************************************************************
 * 函数名称: iot_thread
 * 说    明: iot线程
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
// extern int motor_wait;
void iot_thread(void *args) {
  uint8_t mac_address[12] = {0x00, 0xdc, 0xb6, 0x90, 0x01, 0x00,0};

  char ssid[32]=ROUTE_SSID;
  char password[32]=ROUTE_PASSWORD;
  char mac_addr[32]={0};

  FlashDeinit();
  FlashInit();

  VendorSet(VENDOR_ID_WIFI_MODE, "STA", 3); // 配置为Wifi STA模式
  VendorSet(VENDOR_ID_MAC, mac_address, 6); // 多人同时做该实验，请修改各自不同的WiFi MAC地址
  VendorSet(VENDOR_ID_WIFI_ROUTE_SSID, ssid, sizeof(ssid));
  VendorSet(VENDOR_ID_WIFI_ROUTE_PASSWD, password,sizeof(password));

reconnect:
  SetWifiModeOff();
  int ret = SetWifiModeOn();
  if(ret != 0){
    printf("wifi connect failed,please check wifi config and the AP!\n");
    return;
  }
  mqtt_init();

  while (1) {
    if (!wait_message()) {
      goto reconnect;
    }
    LOS_Msleep(1);
    // if(motor_wait >0)
    // {
    //     motor_wait--;
    //     if(motor_wait <= 0){
    //         motor_set_state(false);
    //         lcd_set_motor_state(false);
    //     }
    // }
  }
 }

/***************************************************************
 * 函数名称: smart_hone_example
 * 说    明: 开机自启动调用函数
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void smart_hone_example()
{
    unsigned int thread_id_1;
    unsigned int thread_id_2;
    unsigned int thread_id_3;
    unsigned int thread_id_4;
    TSK_INIT_PARAM_S task_1 = {0};
    TSK_INIT_PARAM_S task_2 = {0};
    TSK_INIT_PARAM_S task_3 = {0};
    TSK_INIT_PARAM_S task_4 = {0};

    unsigned int ret = LOS_OK;

    ret = LOS_QueueCreate("queue", MSG_QUEUE_LENGTH, &m_msg_queue, 0, BUFFER_LEN);
    if (ret != LOS_OK)
    {
        printf("Falied to create Message Queue ret:0x%x\n", ret);
        return;
    }

    ret = LOS_QueueCreate("su03_queue", MSG_QUEUE_LENGTH, &m_su03_msg_queue, 0, BUFFER_LEN);
    if (ret != LOS_OK)
    {
        printf("Falied to create Message Queue ret:0x%x\n", ret);
        return;
    }

    task_1.pfnTaskEntry = (TSK_ENTRY_FUNC)smart_hone_thread;
    task_1.uwStackSize = 2048;
    task_1.pcName = "smart hone thread";
    task_1.usTaskPrio = 24;
    ret = LOS_TaskCreate(&thread_id_1, &task_1);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;
    }

    task_2.pfnTaskEntry = (TSK_ENTRY_FUNC)device_read_thraed;
    task_2.uwStackSize = 2048;
    task_2.pcName = "device read thraed";
    task_2.usTaskPrio = 24;
    ret = LOS_TaskCreate(&thread_id_2, &task_2);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;
    }

    task_3.pfnTaskEntry = (TSK_ENTRY_FUNC)diy_thread;
    task_3.uwStackSize = 2048;
    task_3.pcName = "diy thread";
    task_3.usTaskPrio = 24;
    ret = LOS_TaskCreate(&thread_id_3, &task_3);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;
    }

    task_4.pfnTaskEntry = (TSK_ENTRY_FUNC)iot_thread;
    task_4.uwStackSize = 20480*5;
    task_4.pcName = "iot thread";
    task_4.usTaskPrio = 24;
    ret = LOS_TaskCreate(&thread_id_4, &task_4);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;
    }
}

APP_FEATURE_INIT(smart_hone_example);
